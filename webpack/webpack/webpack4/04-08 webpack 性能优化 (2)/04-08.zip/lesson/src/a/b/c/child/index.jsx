import React, { Component } from 'react';

export default class Child extends Component {
	render() {
		return (
			<div>
				<div>This is Child</div>
			</div>
		)
	}
}
