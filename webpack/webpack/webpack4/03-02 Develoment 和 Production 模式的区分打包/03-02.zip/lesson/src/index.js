// Tree Shaking 只支持 ES Module

import { add } from './math.js';

add(1, 7);
