import './index.scss';

var root = document.getElementById('root');
root.innerHTML = '<div class="iconfont icon-changjingguanli"></div>';