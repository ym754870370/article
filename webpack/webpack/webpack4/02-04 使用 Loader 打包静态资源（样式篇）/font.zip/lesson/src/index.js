var root = document.getElementById('root');
import './index.scss';

root.innerHTML = '<div class="iconfont icon-changjingguanli"></div>';