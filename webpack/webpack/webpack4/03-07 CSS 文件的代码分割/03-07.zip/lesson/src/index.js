import './style.css';
import './style1.css';

console.log('hello world');